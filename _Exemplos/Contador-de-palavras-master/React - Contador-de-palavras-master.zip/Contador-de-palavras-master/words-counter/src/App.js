import React from 'react';
import WordCounterApp from './components/CounterApp'

export default function App () {
  return (
    <WordCounterApp />    
  );
}
