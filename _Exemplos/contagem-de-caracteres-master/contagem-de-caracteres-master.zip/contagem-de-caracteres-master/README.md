# Contagem de caracteres

	É um simples script para facilitar a contagem de caracteres digitados
	

## Como usar

	Basta colar o texto desejado ou digitá-lo no campo disponível que o script conta a quantidade de caracteres que o mesmo possui
	
